// swerve_kinematics.h — 3‑module body→wheel kinematics with guardrails (no inversion here)
#pragma once
#include <stdint.h>
#include <stdbool.h>


#ifdef __cplusplus
extern "C" {
#endif


typedef struct {
// Robot geometry (meters) — positions of each module center in body frame (+x fwd, +y left)
float x[3];
float y[3];


// Limits
float v_module_max_mps; // per‑wheel linear speed cap
float wz_max_rad_s; // chassis yaw‑rate cap


// Guardrails
float twist_deadband_v; // m/s; small vx|vy are zeroed
float twist_deadband_w; // rad/s; small wz is zeroed
float wheel_deadband_v; // m/s; below this, hold last angle


// Slew limits per 10 ms tick (100 Hz)
float dvx_max_per_tick; // m/s per tick
float dvy_max_per_tick; // m/s per tick
float dwz_max_per_tick; // rad/s per tick
} SK_Config;


// Runtime state
typedef struct {
SK_Config cfg;
// commanded (user) twist target
float vx_cmd, vy_cmd, wz_cmd;
// filtered/slewed twist actually applied this tick
float vx, vy, wz;
// last commanded angles for each wheel (rad), used to hold when speed < deadband
float ang_prev[3];
} SK_State;


// Output per tick
typedef struct {
float angle_rad[3]; // wheel angles in (−pi, pi]
float speed_mps[3]; // wheel linear speeds (>=0)
float scale; // if any wheel saturated, common scaling applied
} SK_Out;


void sk_init(SK_State* s, const SK_Config* cfg);


// Set a new body twist command (units: m/s, m/s, rad/s); these are targets that will be slewed in update.
static inline void sk_set_twist(SK_State* s, float vx, float vy, float wz){ s->vx_cmd=vx; s->vy_cmd=vy; s->wz_cmd=wz; }


// Compute per‑wheel targets. Call at 100 Hz (10 ms cadence). No inversion/shortest‑path here.
void sk_update_100Hz(SK_State* s, SK_Out* out);


#ifdef __cplusplus
}
#endif
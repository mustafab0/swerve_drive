// swerve_kinematics.c
#include "../Inc/swerve_kinematics.h"
#include <math.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


static inline float wrap_pi(float a){
while(a<=-M_PI) a+=2.0f*(float)M_PI;
while(a> M_PI) a-=2.0f*(float)M_PI;
return a;
}
static inline float clampf(float v,float lo,float hi){return v<lo?lo:(v>hi?hi:v);}
static inline float hypot2(float x,float y){return sqrtf(x*x+y*y);}


void sk_init(SK_State* s, const SK_Config* cfg){
s->cfg = *cfg;
s->vx_cmd = s->vy_cmd = s->wz_cmd = 0.0f;
s->vx = s->vy = s->wz = 0.0f;
s->ang_prev[0] = s->ang_prev[1] = s->ang_prev[2] = 0.0f;
}


void sk_update_100Hz(SK_State* s, SK_Out* out){
const SK_Config* c = &s->cfg;


// 1) Deadband commanded twist
float vx_t = (fabsf(s->vx_cmd) < c->twist_deadband_v) ? 0.0f : s->vx_cmd;
float vy_t = (fabsf(s->vy_cmd) < c->twist_deadband_v) ? 0.0f : s->vy_cmd;
float wz_t = (fabsf(s->wz_cmd) < c->twist_deadband_w) ? 0.0f : s->wz_cmd;


// 2) Clamp to absolute chassis limits
vx_t = clampf(vx_t, -c->v_module_max_mps, c->v_module_max_mps); // loose bound
vy_t = clampf(vy_t, -c->v_module_max_mps, c->v_module_max_mps);
wz_t = clampf(wz_t, -c->wz_max_rad_s, c->wz_max_rad_s);


// 3) Slew toward targets (per 10 ms tick)
float dvx = clampf(vx_t - s->vx, -c->dvx_max_per_tick, c->dvx_max_per_tick);
float dvy = clampf(vy_t - s->vy, -c->dvy_max_per_tick, c->dvy_max_per_tick);
float dwz = clampf(wz_t - s->wz, -c->dwz_max_per_tick, c->dwz_max_per_tick);
s->vx += dvx; s->vy += dvy; s->wz += dwz;


// 4) Raw wheel vectors (no inversion here)
float max_speed = 0.0f;
for(int i=0;i<3;i++){
float tx = -s->wz * c->y[i];
float ty = s->wz * c->x[i];
float Vx = s->vx + tx;
float Vy = s->vy + ty;
float sp = hypot2(Vx, Vy);
float ang = (sp < c->wheel_deadband_v) ? s->ang_prev[i] : atan2f(Vy, Vx);
ang = wrap_pi(ang);
out->angle_rad[i] = ang;
out->speed_mps[i] = (sp < c->wheel_deadband_v) ? 0.0f : sp; // hold angle when nearly stopped
if(out->speed_mps[i] > max_speed) max_speed = out->speed_mps[i];
}


// 5) Uniform scaling if any wheel exceeds module limit
out->scale = 1.0f;
if(max_speed > c->v_module_max_mps){
float scale = c->v_module_max_mps / (max_speed + 1e-9f);
out->scale = scale;
for(int i=0;i<3;i++) out->speed_mps[i] *= scale;
}


// 6) Save angles for hold behavior
for(int i=0;i<3;i++) s->ang_prev[i] = out->angle_rad[i];
}